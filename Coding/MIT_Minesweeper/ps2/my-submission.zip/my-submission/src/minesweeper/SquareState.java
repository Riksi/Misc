package minesweeper;

public enum SquareState {
	UNTOUCHED, DUG, FLAGGED
}
