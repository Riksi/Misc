package minesweeper;

public enum BoardModification {
	FLAG,DEFLAG,DIG;
}
