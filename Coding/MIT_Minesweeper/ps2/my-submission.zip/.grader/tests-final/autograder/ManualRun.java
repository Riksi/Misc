package autograder;

import java.io.IOException;

public class ManualRun {
    public static void main(String args[]) throws IOException {
        TestUtil.startServer(false, "board_file_3");
    }
}
